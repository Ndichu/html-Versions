{/* <style>
    .div {
      padding-top: 16px;
      align-items: center;
      display: flex;
      flex-direction: column;
      overflow: hidden;
    }
    
    .div-137 {
      background-color: var(--Green, #24a86a);
      align-self: center;
      display: flex;
      margin-top: 16px;
      width: 100%;
      flex-direction: column;
      padding: 24px 60px 50px;
    }
    @media (max-width: 991px) {
      .div-137 {
        max-width: 100%;
        padding: 0 20px;
      }
    }
    .div-138 {
      padding-bottom: 16px;
      justify-content: space-between;
      align-items: start;
      display: flex;
      margin-bottom: 7px;
      gap: 20px;
    }
    @media (max-width: 991px) {
      .div-138 {
        max-width: 100%;
        flex-wrap: wrap;
        justify-content: center;
      }
    }
    .div-139 {
      justify-content: flex-end;
      align-items: start;
      display: flex;
      flex-direction: column;
      padding: 16px 0;
    }
    .div-140 {
      color: var(--Whitee, #fff);
      letter-spacing: 0.96px;
      align-self: stretch;
      
      font: 400 32px/150% Monoton, sans-serif;
    }
    .div-141 {
      color: var(--White, #fff);
      align-self: stretch;
      margin-top: 16px;
      white-space: nowrap;
      font: 700 18px/156% Montserrat, sans-serif;
    }
    @media (max-width: 991px) {
      .div-141 {
        white-space: initial;
      }
    }
    .img-32 {
      aspect-ratio: 3;
      object-fit: contain;
      object-position: center;
      width: 108px;
      align-items: flex-start;
      overflow: hidden;
      margin-top: 8px;
      max-width: 100%;
    }
    .div-142 {
      align-self: stretch;
      display: flex;
      flex-direction: column;
    }
    .div-143 {
      display: flex;
      flex-direction: column;
      padding: 15px 27px;
    }
    @media (max-width: 991px) {
      .div-143 {
        padding: 0 20px;
      }
    }
    .div-144 {
      color: var(--White, #fff);
      font: 700 18px/156% Montserrat, sans-serif;
    }
    .img-33a {
      
      object-fit: contain;
      object-position: center;
      width: 30px;
      align-self: center;
      stroke-width: 4px;
      stroke: var(--Whitee, #fff);
      overflow: hidden;
      
    }
    .div-145a {
      display: flex;
      flex-direction: row;
      padding: 0 24px 24px;
    }
    @media (max-width: 991px) {
      .div-145a {
        padding: 0 20px;
      }
    }
    .div-146a {
      align-items: start;
      display: flex;
      gap: 16px;
      margin-right: 16px
    }
    .img-33 {
      aspect-ratio: 35.25;
      object-fit: contain;
      object-position: center;
      width: 141px;
      align-self: center;
      stroke-width: 4px;
      stroke: var(--Whitee, #fff);
      overflow: hidden;
      margin-top: 6px;
    }
    .div-145 {
      display: flex;
      flex-direction: column;
      padding: 0 24px 24px;
    }
    @media (max-width: 991px) {
      .div-145 {
        padding: 0 20px;
      }
    }
    .div-146 {
      align-items: start;
      display: flex;
      gap: 16px;
    }
    .img-34 {
      aspect-ratio: 1;
      object-fit: contain;
      object-position: center;
      width: 20px;
      overflow: hidden;
      max-width: 100%;
    }
    .div-147 {
      color: var(--White, #fff);
      font: 400 14px/160% Montserrat, sans-serif;
    }
    .div-148 {
      align-items: start;
      display: flex;
      margin-top: 16px;
      gap: 16px;
    }
    .img-35 {
      aspect-ratio: 1;
      object-fit: contain;
      object-position: center;
      width: 20px;
      overflow: hidden;
      max-width: 100%;
    }
    .div-149 {
      color: var(--White, #fff);
      font: 400 14px/160% Montserrat, sans-serif;
    }
    .div-150 {
      align-items: start;
      display: flex;
      margin-top: 16px;
      gap: 16px;
    }
    .img-36 {
      aspect-ratio: 1;
      object-fit: contain;
      object-position: center;
      width: 20px;
      overflow: hidden;
      max-width: 100%;
    }
    .div-151 {
      color: var(--White, #fff);
      font: 400 14px/160% Montserrat, sans-serif;
    }
    .div-152 {
      border-radius: 16px;
      align-self: stretch;
      display: flex;
      flex-direction: column;
    }
    .div-153 {
      display: flex;
      flex-direction: column;
      padding: 15px 22px;
    }
    @media (max-width: 991px) {
      .div-153 {
        padding: 0 20px;
      }
    }
    .div-154 {
      color: var(--White, #fff);
      white-space: nowrap;
      font: 700 18px/156% Montserrat, sans-serif;
    }
    @media (max-width: 991px) {
      .div-154 {
        white-space: initial;
      }
    }
    .img-37 {
      aspect-ratio: 49;
      object-fit: contain;
      object-position: center;
      width: 196px;
      align-self: center;
      stroke-width: 4px;
      stroke: var(--Whitee, #fff);
      overflow: hidden;
      margin-top: 6px;
    }
    .div-155 {
      display: flex;
      flex-direction: column;
      padding: 0 26px 24px;
    }
    @media (max-width: 991px) {
      .div-155 {
        padding: 0 20px;
      }
    }
    .div-156 {
      align-items: start;
      display: flex;
      gap: 16px;
    }
    .img-38 {
      aspect-ratio: 1;
      object-fit: contain;
      object-position: center;
      width: 20px;
      overflow: hidden;
      max-width: 100%;
    }
    .div-157 {
      color: var(--White, #fff);
      font: 400 14px/160% Montserrat, sans-serif;
    }
    .div-158 {
      align-items: start;
      display: flex;
      margin-top: 16px;
      gap: 16px;
    }
    .img-39 {
      aspect-ratio: 1;
      object-fit: contain;
      object-position: center;
      width: 20px;
      overflow: hidden;
      max-width: 100%;
    }
    .div-159 {
      color: var(--White, #fff);
      text-decoration-line: underline;
      align-self: stretch;
      flex-grow: 1;
      white-space: nowrap;
      font: 400 14px/150% Montserrat, sans-serif;
    }
    @media (max-width: 991px) {
      .div-159 {
        white-space: initial;
      }
    }
    .div-160 {
      align-items: start;
      display: flex;
      margin-top: 16px;
      gap: 16px;
    }
    .img-40 {
      aspect-ratio: 1;
      object-fit: contain;
      object-position: center;
      width: 20px;
      overflow: hidden;
      max-width: 100%;
    }
    .div-161 {
      color: var(--White, #fff);
      font: 400 14px/160% Montserrat, sans-serif;
    }
    .div-162 {
    color: var(--White, #fff);
    text-align: center;
    letter-spacing: -0.48px;
    max-width: 486px;
    align-self: center;
    font: 500 22px/33px Montserrat, sans-serif;
  }
  @media (max-width: 991px) {
    .div-162 {
      max-width: 100%;
    }
  }
  </style> */}


<>
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
    integrity="sha384-GLhlTQ8iKu1f1J3px5F6zuNMNDBKOQm2rE5K91A+Ou2EGJLZ5Ll5M5tM35Mjw"
    crossOrigin="anonymous"
  />
  <div className="div">
    <div className="div-137">
      <div className="div-138">
        <div className="div-139">
          <div className="div-140">OneSkin</div>
          <div className="div-143">
            <div className="div-144">Follow Us On Our Socials</div>
          </div>
          <div className="div-145a">
            <div className="div-146a">
              <img loading="lazy" src="Facebook.png" className="img-33a" />
            </div>
            <div className="div-146a">
              <img loading="lazy" src="twitter.png" className="img-33a" />
            </div>
            <div className="div-146a">
              <img loading="lazy" src="instagram.png" className="img-33a" />
            </div>
          </div>
        </div>
        <div className="div-142">
          <div className="div-143">
            <div className="div-144">Quick Links</div>
            <img
              loading="lazy"
              src="https://cdn.builder.io/api/v1/image/assets/TEMP/e55d9d93efda93411a1ed5ba51882de53cc055837d760e88d37f91147b453ad0?apiKey=4b67c500605a43ffbc74a1ee09f059f5&"
              className="img-33"
            />
          </div>
          <div className="div-145">
            <div className="div-146">
              <img
                loading="lazy"
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/d4d516b076f60c4dbbf73019a2f9634678938eddcff9e8aa6593f1392203e680?apiKey=4b67c500605a43ffbc74a1ee09f059f5&"
                className="img-34"
              />
              <div className="div-147">
                <a
                  href="#"
                  target="_blank"
                  style={{ color: "white", textDecoration: "none" }}
                >
                  Know Your Skin
                </a>
              </div>
            </div>
            <div className="div-148">
              <img
                loading="lazy"
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/42d975b54741f439d088fc1e151c66fb27286624524dce5b0686691171222f29?apiKey=4b67c500605a43ffbc74a1ee09f059f5&"
                className="img-35"
              />
              <div className="div-149">
                <a
                  href="#"
                  target="_blank"
                  style={{ color: "white", textDecoration: "none" }}
                >
                  Our Products
                </a>
              </div>
            </div>
            <div className="div-150">
              <img
                loading="lazy"
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/1f2c8d5bac2a644a11afd05ae4e681c1b4d3ffce7911a6c18c19ceb75be72119?apiKey=4b67c500605a43ffbc74a1ee09f059f5&"
                className="img-36"
              />
              <div className="div-151">
                <a
                  href="#"
                  target="_blank"
                  style={{ color: "white", textDecoration: "none" }}
                >
                  About Us
                </a>
              </div>
            </div>
          </div>
        </div>
        <div className="div-152">
          <div className="div-153">
            <div className="div-154">Contact Information</div>
            <img
              loading="lazy"
              src="https://cdn.builder.io/api/v1/image/assets/TEMP/a36cfdce7334c0e0898e18933f556a0a41c3526bd068a23f81f252d3b91aaa4e?apiKey=4b67c500605a43ffbc74a1ee09f059f5&"
              className="img-37"
            />
          </div>
          <div className="div-155">
            <div className="div-156">
              <img
                loading="lazy"
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/6db039cd393a47c27b535a0e16d3e12e268dcca5ee8e3ccf2b0cfc24d694aeae?apiKey=4b67c500605a43ffbc74a1ee09f059f5&"
                className="img-38"
              />
              <div
                className="div-157"
                style={{
                  color: "white",
                  fontSize: 14,
                  fontFamily: "Montserrat",
                  fontWeight: 400,
                  lineHeight: "22.40px",
                  wordWrap: "break-word"
                }}
              >
                <a
                  href="tel:0741000000"
                  target="_blank"
                  style={{ color: "white", textDecoration: "none" }}
                >
                  0741 000 000
                </a>
              </div>
            </div>
            <div className="div-158">
              <img
                loading="lazy"
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/14fecd7f9f1b16162383a810bf7b17920fb86e020ffb003c8f72435f3bc15a29?apiKey=4b67c500605a43ffbc74a1ee09f059f5&"
                className="img-39"
              />
              <div className="div-159">
                <a
                  href="tel:info@oneskin.co.ke"
                  target="_blank"
                  style={{ color: "white", textDecoration: "none" }}
                >
                  info@oneskin.co.ke
                </a>
              </div>
            </div>
            <div className="div-160">
              <img
                loading="lazy"
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/61294cde4ff3a0f91a89602d3e57c91b4f2313d9bd3bed6824ae8bbe41ce0896?apiKey=4b67c500605a43ffbc74a1ee09f059f5&"
                className="img-40"
              />
              <div className="div-161">P.O Box 1913</div>
            </div>
          </div>
        </div>
      </div>
      <div className="div-162">
        © 2023 Copyright OneSkin. All rights reserved
      </div>
    </div>
  </div>
</>
