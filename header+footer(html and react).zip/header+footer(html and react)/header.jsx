{/* <style>
  .div {
    justify-content: flex-end;
    align-items: flex-start;
    background-color: var(--gray-50, #f9fafb);
    display: flex;
    flex-direction: column;
  }
  .div-2 {
    padding-bottom: 10px;
    justify-content: center;
    align-items: center;
    align-self: center;
    overflow: hidden;
    background-color: var(--Brown-BG, #fcefed);
    display: flex;
    width: 100%;
    flex-direction: column;
    position: relative;
  }
  @media (max-width: 991px) {
    .div-2 {
      max-width: 100%;
    }
  }
  .div-3 {
    background-color: var(--Brown-BG, #fcefed);
    align-self: center;
    display: flex;
    width: 100%;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    padding: 15px 60px;
  }
  @media (max-width: 991px) {
    .div-3 {
      max-width: 100%;
      flex-wrap: wrap;
      padding: 0 20px;
    }
  }
  .div-4 {
    color: var(--Green, #24a86a);
    letter-spacing: 0.96px;
    margin: auto 0;
    font: 400 32px/150% Monoton, sans-serif;
  }
  .div-5 {
    align-items: flex-start;
    align-self: center;
    display: flex;
    justify-content: space-between;
    gap: 20px;
  }
  @media (max-width: 991px) {
    .div-5 {
      max-width: 100%;
      flex-wrap: wrap;
      justify-content: center;
    }
  }
  .div-6,
  .div-7,
  .div-8,
  .div-9,
  .div-10 {
    color: var(--Green, #24a86a);
    text-align: center;
    letter-spacing: -0.35px;
    align-self: center;
    margin: auto 0;
    font: 700 16px/150% Montserrat, sans-serif;
  }
  .div-6 {
    white-space: nowrap;
    border-bottom: 1px solid var(--Green, #24a86a);
    aspect-ratio: 1.5909090909090908;
    padding: 0px;
  }
  @media (max-width: 991px) {
    .div-6 {
      white-space: initial;
    }
  }
  .div-7,
  .div-8,
  .div-9 {
    color: var(--TextColor, #333);
    font: 400 16px/150% Montserrat, sans-serif;
  }
  .div-10 {
    color: var(--white, #fff);
    white-space: nowrap;
    justify-content: center;
    align-items: center;
    border-radius: 100px;
    box-shadow: 0px 1px 2px 0px rgba(0, 0, 0, 0.05);
    background-color: var(--Green, #24a86a);
    align-self: center;
    flex-grow: 1;
    padding: 13px 60px;
    font: 500 16px/150% Montserrat, sans-serif;
  }
  @media (max-width: 991px) {
    .div-10 {
      white-space: initial;
      padding: 0 20px;
    }
  }
  .img {
    aspect-ratio: 1;
    object-fit: contain;
    object-position: center;
    width: 24px;
    overflow: hidden;
    align-self: center;
    max-width: 100%;
    margin: auto 0;
  }
  a {
    text-decoration: none;
  }
</style> */}




<div className="div">
  <div className="div-2">
    <div className="div-3">
      <div className="div-4">
        <span style={{ color: "rgba(132, 64, 47, 1)" }}>O</span>
        <span style={{ color: "rgba(36, 168, 106, 1)" }}>ne</span>
        <span style={{ color: "rgba(132, 64, 47, 1)" }}>S</span>
        <span style={{ color: "rgba(36, 168, 106, 1)" }}>kin</span>
      </div>
      <div className="div-5">
        <a href="#6" className="div-6">
          Home
        </a>
        <a href="#7" className="div-7">
          Products
        </a>
        <a href="#8" className="div-8">
          Our Process
        </a>
        <a href="#9" className="div-9">
          Testimonials
        </a>
        <a href="#10" className="div-10">
          Get Your Custom Formula
        </a>
        <a href="#user-link" className="img">
          <img
            loading="lazy"
            src="https://cdn.builder.io/api/v1/image/assets/TEMP/e09122ed48ea553c04a68273b6509bb6168d19f8df085daf8f1f4ea2c6e99f85?apiKey=4b67c500605a43ffbc74a1ee09f059f5&"
            className="img"
            alt="user icon"
          />
        </a>
        <a href="#search-link" className="img">
          <img
            loading="lazy"
            src="https://cdn.builder.io/api/v1/image/assets/TEMP/0b2d200fedb695edf039588710edb1b7b11f137a135cec1d74cd0a65c07272e8?apiKey=4b67c500605a43ffbc74a1ee09f059f5&"
            className="img"
            alt="search icon"
          />
        </a>
      </div>
    </div>
  </div>
</div>
