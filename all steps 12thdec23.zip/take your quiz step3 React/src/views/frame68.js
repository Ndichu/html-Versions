import React from 'react'

import { Helmet } from 'react-helmet'

import './frame68.css'

const Frame68 = (props) => {
  return (
    <div className="frame68-container">
      <Helmet>
        <title>exported project</title>
      </Helmet>
      <div className="frame68-frame68">
        <div className="frame68-frame186">
          <div className="frame68-frame221">
            <div className="frame68-page-headings-backlink">
              <div className="frame68-breadcrumb-link">
                <span className="frame68-text">
                  <span>Back</span>
                </span>
              </div>
              <img
                src="/external/chevronlefti270-l83.svg"
                alt="ChevronleftI270"
                className="frame68-chevronleft"
              />
            </div>
            <span className="frame68-text02">
              <span>Take Your Skin Quiz</span>
            </span>
          </div>
          <div className="frame68-bullets-desktop">
            <span className="frame68-text04">
              <span>Step 2 of 4</span>
            </span>
            <div className="frame68-bullets">
              <img
                src="/external/badgecheck2703-fxy.svg"
                alt="Badgecheck2703"
                className="frame68-badgecheck"
              />
              <div className="frame68-step-bullet">
                <img
                  src="/external/currentindicator2703-k9ul-200h.png"
                  alt="Currentindicator2703"
                  className="frame68-currentindicator"
                />
                <img
                  src="/external/dot2703-8cwp-200h.png"
                  alt="Dot2703"
                  className="frame68-dot"
                />
              </div>
              <div className="frame68-step-bullet1"></div>
              <div className="frame68-step-bullet2"></div>
            </div>
          </div>
          <span className="frame68-text06">
            <span>Select your skin goals (up to 3)</span>
          </span>
          <div className="frame68-frame183">
            <div className="frame68-component8">
              <span className="frame68-text08">
                <span>Hydrate</span>
              </span>
            </div>
            <div className="frame68-component9">
              <span className="frame68-text10">
                <span>Rejuvenate</span>
              </span>
              <button className="frame68-slideovers-closebutton">
                <img
                  src="/external/xi270-pde.svg"
                  alt="XI270"
                  className="frame68-x"
                />
              </button>
            </div>
            <div className="frame68-component10">
              <span className="frame68-text12">
                <span>Brighten</span>
              </span>
            </div>
            <div className="frame68-component11">
              <span className="frame68-text14">
                <span>Calm/soothe</span>
              </span>
            </div>
          </div>
          <div className="frame68-frame1861">
            <div className="frame68-component15">
              <span className="frame68-text16">
                <span>Minimize redness</span>
              </span>
            </div>
            <div className="frame68-component14">
              <span className="frame68-text18">
                <span>Tighten</span>
              </span>
            </div>
            <div className="frame68-component13">
              <span className="frame68-text20">
                <span>Minimize pores</span>
              </span>
              <button className="frame68-slideovers-closebutton1">
                <img
                  src="/external/xi270-8anpelw.svg"
                  alt="XI270"
                  className="frame68-x1"
                />
              </button>
            </div>
            <div className="frame68-component12">
              <span className="frame68-text22">
                <span>Smooth</span>
              </span>
            </div>
          </div>
          <div className="frame68-frame184">
            <div className="frame68-component81">
              <span className="frame68-text24">
                <span>Reduce shine</span>
              </span>
            </div>
            <div className="frame68-component91">
              <span className="frame68-text26">
                <span>Anti-pollution</span>
              </span>
            </div>
            <div className="frame68-component101">
              <span className="frame68-text28">
                <span>Even tone</span>
              </span>
            </div>
            <div className="frame68-component111">
              <span className="frame68-text30">
                <span>Reduce breakouts</span>
              </span>
            </div>
          </div>
          <img
            src="/external/line82703-48f9.svg"
            alt="Line82703"
            className="frame68-line8"
          />
          <span className="frame68-text32">
            <span>Your Goals</span>
          </span>
          <div className="frame68-frame189">
            <div className="frame68-frame188">
              <span className="frame68-text34">
                <span>Rejuvenate</span>
              </span>
              <span className="frame68-text36">
                <span>
                  Visibly reduces the appearance of lines and deep wrinkles for
                  more youthful-looking skin.
                </span>
              </span>
              <img
                src="/external/fluentdelete48regular2703-4nga.svg"
                alt="fluentdelete48regular2703"
                className="frame68-fluentdelete48regular"
              />
            </div>
            <img
              src="/external/line92703-9rzr.svg"
              alt="Line92703"
              className="frame68-line9"
            />
            <div className="frame68-frame191">
              <span className="frame68-text38">
                <span>Ingredients:</span>
              </span>
              <div className="frame68-frame190">
                <div className="frame68-component82">
                  <span className="frame68-text40">
                    <span>Argireline (peptide)</span>
                  </span>
                  <img
                    src="/external/informationcircle2703-nndm.svg"
                    alt="Informationcircle2703"
                    className="frame68-informationcircle"
                  />
                </div>
                <div className="frame68-component92">
                  <span className="frame68-text42">
                    <span>Tiger Grass centella asiatica</span>
                  </span>
                  <img
                    src="/external/informationcircle2703-fvws.svg"
                    alt="Informationcircle2703"
                    className="frame68-informationcircle1"
                  />
                </div>
              </div>
            </div>
          </div>
          <img
            src="/external/line132703-u9es.svg"
            alt="Line132703"
            className="frame68-line13"
          />
          <div className="frame68-frame1901">
            <div className="frame68-frame1881">
              <span className="frame68-text44">
                <span>Minimize Pores</span>
              </span>
              <span className="frame68-text46">
                <span>
                  Visibly reduces pore size and pore darkening, smoothing the
                  look of skin texture.
                </span>
              </span>
              <img
                src="/external/fluentdelete48regular2703-mldk.svg"
                alt="fluentdelete48regular2703"
                className="frame68-fluentdelete48regular1"
              />
            </div>
            <img
              src="/external/line92703-6tfk.svg"
              alt="Line92703"
              className="frame68-line91"
            />
            <div className="frame68-frame1911">
              <span className="frame68-text48">
                <span>Ingredients:</span>
              </span>
              <div className="frame68-frame1902">
                <div className="frame68-component83">
                  <span className="frame68-text50">
                    <span>Argireline (peptide)</span>
                  </span>
                  <img
                    src="/external/informationcircle2703-ktct.svg"
                    alt="Informationcircle2703"
                    className="frame68-informationcircle2"
                  />
                </div>
                <div className="frame68-component93">
                  <span className="frame68-text52">
                    <span>Tiger Grass centella asiatica</span>
                  </span>
                  <img
                    src="/external/informationcircle2703-cnjg.svg"
                    alt="Informationcircle2703"
                    className="frame68-informationcircle3"
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="frame68-frame1912">
            <button className="frame68-button">
              <span className="frame68-text54">
                <span>Back</span>
              </span>
            </button>
            <button className="frame68-button1">
              <span className="frame68-text56">
                <span>Next</span>
              </span>
            </button>
          </div>
        </div>
        
      </div>
    </div>
  )
}

export default Frame68
