import React from 'react'

import { Helmet } from 'react-helmet'

import './frame68.css'

const Frame68 = (props) => {
  return (
    <div className="frame68-container">
      <Helmet>
        <title>exported project</title>
      </Helmet>
      <div className="frame68-frame68">
        <div className="frame68-frame185">
          <div className="frame68-frame221">
            <div className="frame68-page-headings-backlink">
              <div className="frame68-breadcrumb-link">
                <span className="frame68-text">
                  <span>Back</span>
                </span>
              </div>
              <img
                src="/external/chevronlefti270-wkgo.svg"
                alt="ChevronleftI270"
                className="frame68-chevronleft"
              />
            </div>
            <span className="frame68-text02">
              <span>Take Your Skin Quiz</span>
            </span>
          </div>
          <div className="frame68-bullets-desktop">
            <span className="frame68-text04">
              <span>Step 2 of 4</span>
            </span>
            <div className="frame68-bullets">
              <img
                src="/external/badgecheck2703-qq6.svg"
                alt="Badgecheck2703"
                className="frame68-badgecheck"
              />
              <div className="frame68-step-bullet">
                <img
                  src="/external/currentindicator2703-7w77-200h.png"
                  alt="Currentindicator2703"
                  className="frame68-currentindicator"
                />
                <img
                  src="/external/dot2703-le3n-200h.png"
                  alt="Dot2703"
                  className="frame68-dot"
                />
              </div>
              <div className="frame68-step-bullet1"></div>
              <div className="frame68-step-bullet2"></div>
            </div>
          </div>
          <span className="frame68-text06">
            <span>Select your skin goals (up to 3)</span>
          </span>
          <div className="frame68-frame218">
            <div className="frame68-frame183">
              <div className="frame68-component8">
                <span className="frame68-text08">
                  <span>Hydrate</span>
                </span>
              </div>
              <div className="frame68-component9">
                <span className="frame68-text10">
                  <span>Rejuvenate</span>
                </span>
              </div>
              <div className="frame68-component10">
                <span className="frame68-text12">
                  <span>Brighten</span>
                </span>
              </div>
              <div className="frame68-component11">
                <span className="frame68-text14">
                  <span>Calm/soothe</span>
                </span>
              </div>
            </div>
            <div className="frame68-frame186">
              <div className="frame68-component15">
                <span className="frame68-text16">
                  <span>Minimize redness</span>
                </span>
              </div>
              <div className="frame68-component14">
                <span className="frame68-text18">
                  <span>Tighten</span>
                </span>
              </div>
              <div className="frame68-component13">
                <span className="frame68-text20">
                  <span>Minimize pores</span>
                </span>
              </div>
              <div className="frame68-component12">
                <span className="frame68-text22">
                  <span>Smooth</span>
                </span>
              </div>
            </div>
            <div className="frame68-frame184">
              <div className="frame68-component81">
                <span className="frame68-text24">
                  <span>Reduce shine</span>
                </span>
              </div>
              <div className="frame68-component91">
                <span className="frame68-text26">
                  <span>Anti-pollution</span>
                </span>
              </div>
              <div className="frame68-component101">
                <span className="frame68-text28">
                  <span>Even tone</span>
                </span>
              </div>
              <div className="frame68-component111">
                <span className="frame68-text30">
                  <span>Reduce breakouts</span>
                </span>
              </div>
            </div>
          </div>
          <div className="frame68-frame187">
            <button className="frame68-button">
              <span className="frame68-text32">
                <span>Back</span>
              </span>
            </button>
            <button className="frame68-button1">
              <span className="frame68-text34">
                <span>Next</span>
              </span>
            </button>
          </div>
        </div>
        
      </div>
    </div>
  )
}

export default Frame68
