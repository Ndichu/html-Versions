import React from 'react'

import { Helmet } from 'react-helmet'

import './frame68.css'

const Frame68 = (props) => {
  return (
    <div className="frame68-container">
      <Helmet>
        <title>exported project</title>
      </Helmet>
      <div className="frame68-frame68">
        <div className="frame68-frame182">
          <div className="frame68-frame221">
            <div className="frame68-page-headings-backlink">
              <div className="frame68-breadcrumb-link">
                <span className="frame68-text">
                  <span>Back</span>
                </span>
              </div>
              <img
                src="/external/chevronlefti490-nqzm.svg"
                alt="ChevronleftI490"
                className="frame68-chevronleft"
              />
            </div>
            <span className="frame68-text02">
              <span>Take Your Skin Quiz</span>
            </span>
          </div>
          <div className="frame68-bullets-desktop">
            <span className="frame68-text04">
              <span>Step 1 of 4</span>
            </span>
            <div className="frame68-bullets">
              <div className="frame68-step-bullet">
                <img
                  src="/external/currentindicator4906-o8sf-200h.png"
                  alt="Currentindicator4906"
                  className="frame68-currentindicator"
                />
                <img
                  src="/external/dot4906-tbfl-200h.png"
                  alt="Dot4906"
                  className="frame68-dot"
                />
              </div>
              <div className="frame68-step-bullet1"></div>
              <div className="frame68-step-bullet2"></div>
              <div className="frame68-step-bullet3"></div>
            </div>
          </div>
          <div className="frame68-frame178">
            <span className="frame68-text06">
              <span>How would you describe your skin type?</span>
            </span>
            <div className="frame68-component5">
              <div className="frame68-frame160">
                <div className="frame68-frame156"></div>
                <span className="frame68-text08">
                  <span>Dry</span>
                </span>
              </div>
              <div className="frame68-frame159">
                <div className="frame68-frame155"></div>
                <span className="frame68-text10">
                  <span>Oily</span>
                </span>
              </div>
              <div className="frame68-frame161">
                <div className="frame68-frame157"></div>
                <span className="frame68-text12">
                  <span>Balanced</span>
                </span>
              </div>
              <div className="frame68-frame162">
                <div className="frame68-frame158"></div>
                <span className="frame68-text14">
                  <span>Normal</span>
                </span>
              </div>
            </div>
          </div>
          <div className="frame68-frame177">
            <span className="frame68-text16">
              <span>How much makeup do you use on a daily basis?</span>
            </span>
            <div className="frame68-component4">
              <div className="frame68-frame1591">
                <img
                  src="/external/frame171i490-5bfd.svg"
                  alt="Frame171I490"
                  className="frame68-frame171"
                />
                <span className="frame68-text18">
                  <span>None</span>
                </span>
              </div>
              <div className="frame68-frame1601">
                <img
                  src="/external/frame172i490-nxl.svg"
                  alt="Frame172I490"
                  className="frame68-frame172"
                />
                <span className="frame68-text20">
                  <span>A little</span>
                </span>
              </div>
              <div className="frame68-frame163">
                <img
                  src="/external/frame172i490-7y28.svg"
                  alt="Frame172I490"
                  className="frame68-frame1721"
                />
                <span className="frame68-text22">
                  <span>
                    <span>A decent</span>
                    <br></br>
                    <span>amount</span>
                  </span>
                </span>
              </div>
              <div className="frame68-frame1621">
                <img
                  src="/external/frame172i490-c3je.svg"
                  alt="Frame172I490"
                  className="frame68-frame1722"
                />
                <span className="frame68-text27">
                  <span>
                    <span>Full</span>
                    <br></br>
                    <span>coverage</span>
                  </span>
                </span>
              </div>
            </div>
          </div>
          <div className="frame68-frame179">
            <span className="frame68-text32">
              <span>How often is your skin sensitive?</span>
            </span>
            <div className="frame68-component6">
              <div className="frame68-frame1592">
                <img
                  src="/external/frame171i490-a3uj.svg"
                  alt="Frame171I490"
                  className="frame68-frame1711"
                />
                <span className="frame68-text34">
                  <span>Never</span>
                </span>
              </div>
              <div className="frame68-frame1602">
                <img
                  src="/external/frame172i490-vtjr.svg"
                  alt="Frame172I490"
                  className="frame68-frame1723"
                />
                <span className="frame68-text36">
                  <span>Rarely</span>
                </span>
              </div>
              <div className="frame68-frame1611">
                <img
                  src="/external/frame173i490-y0xv.svg"
                  alt="Frame173I490"
                  className="frame68-frame173"
                />
                <span className="frame68-text38">
                  <span>Sometimes</span>
                </span>
              </div>
              <div className="frame68-frame1622">
                <img
                  src="/external/frame174i490-3krc.svg"
                  alt="Frame174I490"
                  className="frame68-frame174"
                />
                <span className="frame68-text40">
                  <span>All the time</span>
                </span>
              </div>
            </div>
          </div>
          <div className="frame68-frame222">
            <span className="frame68-text42">
              <span>
                <span>
                  How would you describe your typical level of sunshine exposure
                </span>
                <br></br>
                <span>and environmental factors in your daily routine?</span>
              </span>
            </span>
            <div className="frame68-component19">
              <div className="frame68-frame224">
                <img
                  src="/external/primesuni490-ytzr.svg"
                  alt="primesunI490"
                  className="frame68-primesun"
                />
                <span className="frame68-text47">
                  <span>Minimal</span>
                </span>
              </div>
              <div className="frame68-frame223">
                <img
                  src="/external/risunfilli490-itnj.svg"
                  alt="risunfillI490"
                  className="frame68-risunfill"
                />
                <span className="frame68-text49">
                  <span>Moderate</span>
                </span>
              </div>
              <div className="frame68-frame225">
                <img
                  src="/external/raphaelsuni490-ejc9.svg"
                  alt="raphaelsunI490"
                  className="frame68-raphaelsun"
                />
                <span className="frame68-text51">
                  <span>High</span>
                </span>
              </div>
              <div className="frame68-frame226">
                <img
                  src="/external/fluentdatasunburst24filledi490-9dhp.svg"
                  alt="fluentdatasunburst24filledI490"
                  className="frame68-fluentdatasunburst24filled"
                />
                <span className="frame68-text53">
                  <span>Very High</span>
                </span>
              </div>
            </div>
          </div>
          <button className="frame68-button">
            <span className="frame68-text55">
              <span>Next</span>
            </span>
          </button>
        </div>
        
      </div>
    </div>
  )
}

export default Frame68
